# Quick Start Guide

## For First-Time Setup

### 1. Clone This Repository

```bash
git clone https://github.com/yourusername/nixos-config
cd nixos-config
```

### 2. Build Your Custom ISO

```bash
# Using make
make build-iso

# Or directly
nix build .#installer-iso
```

This creates an ISO with:
- Your configuration pre-loaded
- Interactive installer wizard
- All necessary tools

### 3. Flash to USB

```bash
# Using make
make flash-iso DEVICE=/dev/sdb

# Or manually
sudo dd if=result/iso/nixos-*.iso of=/dev/sdb bs=4M status=progress
```

### 4. Boot and Install

1. Boot from USB
2. Automatically logs in to installer
3. Run: `sudo fish /etc/installer/install-wizard.fish`
4. Follow prompts

Installation takes 10-20 minutes depending on internet speed.

## For Existing Users Installing on New Hardware

### Option A: Use Pre-Built ISO (Easiest)

1. Download ISO from releases
2. Flash to USB
3. Boot and run wizard

### Option B: Direct Network Install (Advanced)

```bash
# From minimal NixOS ISO
sudo -i

# Install git
nix-shell -p git

# Clone config
git clone https://github.com/yourusername/nixos-config /mnt/etc/nixos

# Generate hardware config
nixos-generate-config --root /mnt --show-hardware-config > /mnt/etc/nixos/hosts/$(hostname)/hardware-configuration.nix

# Install
nixos-install --flake /mnt/etc/nixos#$(hostname)
```

## Daily Workflow

### Updating Your System

```bash
# Update flake inputs
make update

# Rebuild system
make rebuild

# Or one command
nix flake update && sudo nixos-rebuild switch --flake .#$(hostname)
```

### Managing VMs

```bash
# Source the helper (or add to config.fish)
source vm-manager.fish

# Create base image (first time)
virt-install --name base-kali \
  --disk path=/var/lib/libvirt/bases/kali-base.qcow2,size=20 \
  --cdrom ~/Downloads/kali.iso \
  --memory 4096 --vcpus 2

# Clone instances instantly
vm_clone kali-base.qcow2 kali-pentest-client1
vm_clone kali-base.qcow2 kali-pentest-client2

# Check disk usage (both clones + base = ~20GB, not 60GB!)
vm_disk_usage
```

### Making Configuration Changes

```bash
# Edit your config
vim hosts/$(hostname)/configuration.nix

# Test without activation
make test

# Apply if good
make rebuild
```

## Dual-Boot Specific

### Pre-Install (One Time)

1. **Boot into current OS** (Bazzite/Windows)
2. **Shrink partition** using Disk Management/GParted
3. **Leave space unallocated**
4. **Boot NixOS installer**
5. **Select "Dual-boot" mode** in wizard

### Post-Install

GRUB should auto-detect other OSes. If not:

```nix
# In your configuration.nix
boot.loader.grub.useOSProber = true;
```

Then rebuild:
```bash
sudo nixos-rebuild switch
```

## VM Reflinking Workflow

### The Three-Step Pattern

```bash
# 1. Create base image (slow, one time)
# Install Kali/Fedora/whatever, configure it how you want

# 2. Save as base
sudo mv /var/lib/libvirt/images/configured-kali.qcow2 \
        /var/lib/libvirt/bases/kali-base.qcow2

# 3. Clone instances (instant)
for target in web-app api database; do
  vm_clone kali-base.qcow2 kali-pentest-$target
done

# Result: 3x 20GB VMs using ~20-25GB total space
```

### Performance Tips

1. **Base images**: Keep pristine, read-only
2. **Clones diverge**: Space grows as they change
3. **Regular cleanup**: Delete unused clones
4. **Snapshots**: Use btrfs snapshots for save states

## Troubleshooting Common Issues

### "No space left" but df shows space

```bash
# Btrfs balance (defrag and reclaim space)
sudo btrfs balance start -dusage=50 /
sudo btrfs filesystem defragment -r /
```

### VMs slow or hung

```bash
# Check if CoW is disabled where it shouldn't be
lsattr /var/lib/libvirt/images/*.qcow2

# Should show "C" flag for performance, no "C" for reflinks
# Fix: chattr +C for performance, chattr -C for reflinks
```

### Can't clone via reflink

```bash
# Verify btrfs
df -T /var/lib/libvirt/images | grep btrfs

# If not btrfs, you need to reinstall with proper template
```

### Dual-boot not showing other OS

```bash
# Update GRUB
sudo nixos-rebuild switch

# Manually regenerate
sudo grub-mkconfig -o /boot/grub/grub.cfg

# Check os-prober found it
sudo os-prober
```

## Advanced Usage

### Custom Disko Template

Create `installer/disko-templates/my-layout.nix`:

```nix
{ device ? "/dev/nvme0n1", ... }:
{
  disko.devices = {
    # Your custom layout
  };
}
```

Add to wizard's options in `install-wizard.fish`.

### Automated Deployment

Create `deploy.sh`:

```bash
#!/usr/bin/env bash
export NIXOS_HOSTNAME="pentest-lab-01"
export NIXOS_USERNAME="pentester"
export NIXOS_INSTALL_TYPE="vm-optimized"
export NIXOS_DISK="/dev/sda"
export NIXOS_GIT_REPO="https://github.com/yourrepo/nixos-config"

sudo fish /etc/installer/install-wizard.fish
```

Run on fresh install: `bash deploy.sh`

### Building for Team Members

```bash
# Build ISO
make build-iso

# Upload to file server
scp result/iso/*.iso your-server:/path/to/isos/

# Share link with team
echo "Download: https://yourserver.com/nixos-custom-$(date +%Y%m%d).iso"
```

## Next Steps

1. **Customize** `hosts/common.nix` with your preferred packages
2. **Add modules** for specific tools (pentesting, development, etc.)
3. **Set up automatic backups** using btrfs snapshots
4. **Configure secrets management** (agenix, sops-nix, etc.)
5. **Create host-specific configs** for different machines

## Getting Help

- Check existing issues on GitHub
- Review disko documentation
- NixOS Discourse forum
- r/NixOS

---

**Remember**: This setup is designed for maximum flexibility and minimal manual work. Once configured, you can deploy to new hardware in under 30 minutes!
